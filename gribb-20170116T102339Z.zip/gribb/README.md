js/three.js: graphic library, based on webGL
js/OrbitControl.js: library for the movement of the camera